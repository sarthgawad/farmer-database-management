
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GoogleGenAI, Modality, LiveServerMessage, Blob as GenAI_Blob } from '@google/genai';
import type { LanguageCode, User } from '../types';
import { TRANSLATIONS, LANGUAGES } from '../constants';
import UserIcon from './icons/UserIcon';
import BotIcon from './icons/BotIcon';
import ThumbsUpIcon from './icons/ThumbsUpIcon';
import ThumbsDownIcon from './icons/ThumbsDownIcon';
import CheckIcon from './icons/CheckIcon';

// --- Encoding/Decoding Helpers ---
function encode(bytes: Uint8Array): string {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

function decode(base64: string): Uint8Array {
  const binaryString = atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

const blobToBase64 = (blob: Blob): Promise<string> => {
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => {
            const result = reader.result as string;
            const base64Data = result.split(',')[1];
            if (base64Data) resolve(base64Data);
            else reject(new Error("Failed to read blob"));
        };
        reader.onerror = (error) => reject(error);
        reader.readAsDataURL(blob);
    });
};

interface LiveAnalysisModalProps {
  isOpen: boolean;
  onClose: () => void;
  language: LanguageCode;
  location: string;
  user: User;
}

const FRAME_RATE = 1.5; 
const JPEG_QUALITY = 0.3; 

const getLiveSystemInstruction = (userName: string, language: LanguageCode): string => {
    const langName = LANGUAGES.find(l => l.code === language)?.name || 'English';

    return `You are Agri-Intel Live Vision. You are a real-time agricultural field assistant for ${userName}.
    
    CRITICAL INSTRUCTIONS:
    1. **VISION-FIRST:** You are receiving live video. Describe the condition of crops, pests, or soil visible in the frame.
    2. **PROACTIVITY:** If you identify a problem (like an insect or leaf spot), you MUST ask the user: "Should I tell you the measures to prevent this?".
    3. **LANGUAGE FLEXIBILITY:** Default is ${langName}. If the user asks to switch languages (e.g., to Hindi, Marathi, Gujarati, or Rajasthani), you MUST comply instantly.
    4. **STRICT SCOPE:** Only answer farming questions. If the user asks for code (C, Python) or anything unrelated to agriculture, politely refuse. Say: "I am specialized in agricultural advisory only."
    5. **NO DENIAL:** Do not say "I cannot see". Proactively analyze the frame.`;
}

const LiveAnalysisModal: React.FC<LiveAnalysisModalProps> = ({ isOpen, onClose, language, location, user }) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const mediaStreamRef = useRef<MediaStream | null>(null);
  const frameIntervalRef = useRef<number | null>(null);
  
  const [status, setStatus] = useState<'idle' | 'connecting' | 'connected' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState('');
  const [feedback, setFeedback] = useState<'none' | 'good' | 'bad'>('none');
  const [showFeedbackThanks, setShowFeedbackThanks] = useState(false);
  
  const sessionRef = useRef<any>(null);
  const inputAudioContextRef = useRef<AudioContext | null>(null);
  const outputAudioContextRef = useRef<AudioContext | null>(null);
  const nextStartTimeRef = useRef<number>(0);
  const audioSourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());

  const cleanup = useCallback(async () => {
    if (frameIntervalRef.current) window.clearInterval(frameIntervalRef.current);
    if (mediaStreamRef.current) mediaStreamRef.current.getTracks().forEach(t => t.stop());
    
    if (sessionRef.current) {
        try { await sessionRef.current.close(); } catch(e) {}
    }
    
    if (outputAudioContextRef.current) await outputAudioContextRef.current.close().catch(() => {});
    if (inputAudioContextRef.current) await inputAudioContextRef.current.close().catch(() => {});
    
    audioSourcesRef.current.forEach(s => { try { s.stop(); } catch(e) {} });
    audioSourcesRef.current.clear();
    
    sessionRef.current = null;
    outputAudioContextRef.current = null;
    inputAudioContextRef.current = null;
    nextStartTimeRef.current = 0;
    setStatus('idle');
    setFeedback('none');
    setShowFeedbackThanks(false);
  }, []);
  
  const handleClose = () => { cleanup(); onClose(); };

  useEffect(() => {
    if (isOpen) startSession();
    else cleanup();
    return () => { cleanup(); };
  }, [isOpen]);

  const startSession = async () => {
    if (status !== 'idle') return;
    setStatus('connecting');
    setErrorMessage('');

    const ai = new GoogleGenAI({ apiKey: process.env.API_KEY as string });
    
    outputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
    inputAudioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });

    try {
      if (outputAudioContextRef.current.state === 'suspended') await outputAudioContextRef.current.resume();
      if (inputAudioContextRef.current.state === 'suspended') await inputAudioContextRef.current.resume();

      const stream = await navigator.mediaDevices.getUserMedia({ 
          audio: { echoCancellation: true, noiseSuppression: true }, 
          video: { width: { ideal: 640 }, height: { ideal: 480 }, facingMode: 'environment' } 
      });
      
      mediaStreamRef.current = stream;
      if (videoRef.current) videoRef.current.srcObject = stream;
      
      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        config: {
          responseModalities: [Modality.AUDIO],
          systemInstruction: getLiveSystemInstruction(user.name, language),
          speechConfig: {
            voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Zephyr' } }
          }
        },
        callbacks: {
          onopen: () => {
            setStatus('connected');
            
            sessionPromise.then(s => {
                sessionRef.current = s;

                const source = inputAudioContextRef.current!.createMediaStreamSource(stream);
                const scriptProcessor = inputAudioContextRef.current!.createScriptProcessor(4096, 1, 1);
                
                scriptProcessor.onaudioprocess = (e) => {
                    if (status === 'error' || !sessionRef.current) return;
                    const inputData = e.inputBuffer.getChannelData(0);
                    const int16 = new Int16Array(inputData.length);
                    for (let i = 0; i < inputData.length; i++) int16[i] = inputData[i] * 32768;
                    
                    const pcmBlob: GenAI_Blob = {
                        data: encode(new Uint8Array(int16.buffer)),
                        mimeType: 'audio/pcm;rate=16000',
                    };
                    s.sendRealtimeInput({ media: pcmBlob });
                };
                source.connect(scriptProcessor);
                scriptProcessor.connect(inputAudioContextRef.current!.destination);

                if (videoRef.current && canvasRef.current) {
                  const videoEl = videoRef.current;
                  const canvasEl = canvasRef.current;
                  const ctx = canvasEl.getContext('2d');
                  
                  frameIntervalRef.current = window.setInterval(async () => {
                      if (!ctx || videoEl.paused || videoEl.ended || !sessionRef.current) return;
                      
                      if (videoEl.videoWidth > 0) {
                          const targetWidth = 320;
                          const targetHeight = (videoEl.videoHeight / videoEl.videoWidth) * targetWidth;
                          canvasEl.width = targetWidth;
                          canvasEl.height = targetHeight;
                          ctx.drawImage(videoEl, 0, 0, targetWidth, targetHeight);
                          
                          const blob = await new Promise<Blob | null>(res => canvasEl.toBlob(res, 'image/jpeg', JPEG_QUALITY));
                          if (blob) {
                              const base64Data = await blobToBase64(blob);
                              sessionRef.current.sendRealtimeInput({
                                  media: { data: base64Data, mimeType: 'image/jpeg' }
                              });
                          }
                      }
                  }, 1000 / FRAME_RATE);
                }
            });
          },
          onmessage: async (message: LiveServerMessage) => {
            const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (base64Audio && outputAudioContextRef.current) {
                const ctx = outputAudioContextRef.current;
                const nextStartTime = Math.max(nextStartTimeRef.current, ctx.currentTime);
                const audioBuffer = await decodeAudioData(decode(base64Audio), ctx, 24000, 1);
                
                const source = ctx.createBufferSource();
                source.buffer = audioBuffer;
                source.connect(ctx.destination);
                source.addEventListener('ended', () => audioSourcesRef.current.delete(source));
                source.start(nextStartTime);
                nextStartTimeRef.current = nextStartTime + audioBuffer.duration;
                audioSourcesRef.current.add(source);
            }
            if (message.serverContent?.interrupted) {
                audioSourcesRef.current.forEach(s => { try { s.stop(); } catch(e) {} });
                audioSourcesRef.current.clear();
                nextStartTimeRef.current = 0;
            }
          },
          onerror: (e: any) => {
            setStatus('error');
            setErrorMessage(e.message || 'Stream link lost.');
          },
          onclose: () => {
            if (status === 'connected') {
                setStatus('error');
                setErrorMessage('Session terminated.');
            }
          },
        },
      });
    } catch (err: any) {
      console.error(err);
      setStatus('error');
      setErrorMessage(err.message || 'Permissions denied.');
      cleanup();
    }
  };

  const handleFeedback = (type: 'good' | 'bad') => {
      setFeedback(type);
      setShowFeedbackThanks(true);
      
      // Reporting feedback to analytics for model improvement
      fetch('/api/feedback', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
              sessionType: 'live_analysis',
              feedback: type,
              userName: user.name,
              location: location,
              timestamp: new Date().toISOString()
          })
      }).catch(() => {});

      setTimeout(() => setShowFeedbackThanks(false), 2000);
  };

  return (
    <>
      {isOpen && (
        <div className="fixed inset-0 bg-black z-[60] flex items-center justify-center animate-fade-in" onClick={handleClose}>
          <div className="w-full h-full flex flex-col relative overflow-hidden" onClick={(e) => e.stopPropagation()}>
            {/* The Video Layer */}
            <video ref={videoRef} className="absolute inset-0 w-full h-full object-cover opacity-80" autoPlay playsInline muted />
            <canvas ref={canvasRef} className="hidden" />
            
            {/* Scanning HUD Overlay */}
            <div className="absolute inset-0 pointer-events-none">
              <div className="absolute top-1/2 left-0 w-full h-px bg-green-500/40 shadow-[0_0_15px_rgba(34,197,94,1)] animate-[scan_3s_ease-in-out_infinite]" />
              {/* Corner Brackets */}
              <div className="absolute top-10 left-10 w-16 h-16 border-t-2 border-l-2 border-green-500/50 rounded-tl-xl" />
              <div className="absolute top-10 right-10 w-16 h-16 border-t-2 border-r-2 border-green-500/50 rounded-tr-xl" />
              <div className="absolute bottom-32 left-10 w-16 h-16 border-b-2 border-l-2 border-green-500/50 rounded-bl-xl" />
              <div className="absolute bottom-32 right-10 w-16 h-16 border-b-2 border-r-2 border-green-500/50 rounded-br-xl" />
            </div>

            <div className="absolute inset-0 bg-gradient-to-t from-black via-transparent to-black/60 flex flex-col justify-between p-6">
                <div className="flex justify-between items-start">
                    <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-2xl px-4 py-2 flex items-center gap-3">
                        <div className={`w-2 h-2 rounded-full ${status === 'connected' ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`}></div>
                        <span className="text-white text-[10px] font-bold tracking-widest uppercase">Live Field Scan</span>
                    </div>
                    <button onClick={handleClose} className="w-12 h-12 rounded-full bg-white/10 backdrop-blur-md flex items-center justify-center text-white hover:bg-white/20 transition-all text-3xl group active:scale-90">
                        &times;
                    </button>
                </div>

                <div className="flex flex-col items-center gap-4">
                    {status === 'connecting' && (
                        <div className="flex flex-col items-center">
                            <div className="w-10 h-10 border-2 border-white/10 border-t-green-500 rounded-full animate-spin mb-4"></div>
                            <p className="text-white/60 text-[10px] font-bold tracking-[0.2em] uppercase">Initializing Neural Link...</p>
                        </div>
                    )}
                    
                    {status === 'error' && (
                        <div className="bg-red-500/10 backdrop-blur-3xl border border-red-500/30 rounded-3xl p-8 max-w-sm text-center">
                            <h3 className="text-white font-bold text-lg mb-2">Network Error</h3>
                            <p className="text-red-200/60 text-xs mb-6">{errorMessage}</p>
                            <button onClick={() => { setStatus('idle'); startSession(); }} className="w-full py-3 bg-white text-black rounded-xl font-bold text-sm">Retry link</button>
                        </div>
                    )}

                    {status === 'connected' && (
                        <div className="flex flex-col items-center gap-4 animate-fade-in">
                            {showFeedbackThanks ? (
                                <div className="bg-green-500/20 backdrop-blur-xl border border-green-500/40 rounded-full px-6 py-2 flex items-center gap-2 text-white text-xs font-bold shadow-2xl animate-bounce">
                                    <CheckIcon /> {TRANSLATIONS.feedbackSent[language]}
                                </div>
                            ) : (
                                <div className="flex gap-4">
                                    <button 
                                        onClick={() => handleFeedback('good')}
                                        className={`w-14 h-14 rounded-full flex items-center justify-center transition-all ${feedback === 'good' ? 'bg-green-500 text-white scale-110' : 'bg-white/5 backdrop-blur-xl border border-white/10 text-white/50 hover:bg-white/10 hover:text-white hover:scale-105'}`}
                                        title={TRANSLATIONS.goodResponse[language]}
                                    >
                                        <ThumbsUpIcon solid={feedback === 'good'} />
                                    </button>
                                    <button 
                                        onClick={() => handleFeedback('bad')}
                                        className={`w-14 h-14 rounded-full flex items-center justify-center transition-all ${feedback === 'bad' ? 'bg-red-500 text-white scale-110' : 'bg-white/5 backdrop-blur-xl border border-white/10 text-white/50 hover:bg-white/10 hover:text-white hover:scale-105'}`}
                                        title={TRANSLATIONS.badResponse[language]}
                                    >
                                        <ThumbsDownIcon solid={feedback === 'bad'} />
                                    </button>
                                </div>
                            )}
                        </div>
                    )}
                </div>
                
                {/* User/Bot Status Icons at the bottom */}
                <div className="flex justify-center gap-12 items-center mb-8">
                   <div className="flex flex-col items-center gap-3">
                        <div className={`w-14 h-14 rounded-full flex items-center justify-center transition-all duration-700 ${status === 'connected' ? 'bg-green-500 text-white shadow-[0_0_30px_rgba(34,197,94,0.4)]' : 'bg-white/10 text-white/20'}`}>
                            <BotIcon className="w-7 h-7" />
                        </div>
                        <span className="text-[9px] text-white/40 font-bold uppercase tracking-widest">AI Partner</span>
                   </div>
                   <div className="h-10 w-px bg-white/10"></div>
                   <div className="flex flex-col items-center gap-3">
                        <div className="w-14 h-14 rounded-full bg-white/10 border border-white/20 flex items-center justify-center text-white/80 shadow-inner">
                            <UserIcon className="w-7 h-7" />
                        </div>
                        <span className="text-[9px] text-white/40 font-bold uppercase tracking-widest">Operator: {user.name}</span>
                   </div>
                </div>
            </div>
            
            <style>{`
                @keyframes scan {
                    0%, 100% { top: 20%; }
                    50% { top: 70%; }
                }
            `}</style>
          </div>
        </div>
      )}
    </>
  );
};

export default LiveAnalysisModal;
